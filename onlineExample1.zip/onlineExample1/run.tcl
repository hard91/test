# Microchip Tcl Script
# PolarFire FPGA Designer
# Date: Mon Nov  9 19:58:22 2026
# Directory C:\usrs\Hardeep
# File C:\usrs\Hardeep\exported.tcl


new_project -location {./project/onlineEample1} -name {onlineEample1} -description {} -type {RTL} -family {PF2X} -die {PF2X7TS_ES} -package {FCNG1369} -speed {-1} -part_range {IND} 
create_smartdesign -sd_name {sd1} 
sd_instantiate_macro -sd_name {sd1} -macro_name {AND2} -instance_name {} 
sd_connect_pin_to_port -sd_name {sd1} -pin_name {AND2_0:Y} 
sd_connect_pin_to_port -sd_name {sd1} -pin_name {AND2_0:B} 
sd_connect_pin_to_port -sd_name {sd1} -pin_name {AND2_0:A} 
generate_component -component_name {sd1} -recursive 0 
build_design_hierarchy 
set_top -module {work.sd1} 
assemble_timing_constraints -synthesis_run_name {synth_run} 
